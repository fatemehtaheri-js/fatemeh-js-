//const musiccard = document.querySelectorAll(".music-card")
//const artist = document.querySelector(".artist")
//const footer = document.querySelector("footer")
//console.log(playmusic.nextSibling); ////in child hast khob bad in chizi gige child nist 
//console.log(names);
//console.log(names);
//console.log(musiccard);
//console.log(playbtn);

const faheart = document.querySelector(".fa-heart")
const playbtn = document.querySelectorAll(".play-btn")
const audios = document.querySelector("audio")
const musicname = document.querySelector(".music-name")
const main = document.querySelector("main")
const forward = document.querySelector(".forward")
const favolumeup = document.querySelector(".volume-icon")
const playicon = document.querySelector(".play-icon")
const button = document.querySelector(".play-button")
const volumecard = document.querySelector(".volume-card")
const volume = document.querySelector(".volume")
const playmusic = document.querySelector(".play-music")
const like = document.querySelector(".like")
const header = document.querySelector("header")
const img = document.querySelector("img")
const volumehandler = document.querySelector(".volume-handler")
const artist = document.querySelector(".artist")
const timeleft = document.querySelector(".time-left")
const processbar = document.querySelector(".process-bar")
const backforward = document.querySelector(".back-forward")
 const childvolume = volumehandler.firstElementChild;
 let mainmusic ;

///check konam chera in var too function bashe nist
 let musicTitle ;
 let currentIndex = 0;
 let mainElem ;
 let time ;
 
 //let currentindex = 0
//console.log(event.target.dataset); ///chon yek dataset dare dige nemigi .src .name agar chand ta bod mikoni
//console.log(musicname);
let data = [

    {id : 6 , name : "پژواک‌های نیمه‌شب - لونا اسکای" , cover : "./1.jpg" , src : "./1.mp3", duration : "1:41" },
    {id : 5 , name : "امواج فردا - افق نقره‌ای" , cover : "./2.jpg" , src : "./2.mp3" , duration : "1:48"},
    {id : 4 , name : "خاکسترهای فروزان - دره اسکارلت" , cover : "./3.jpg" , src :"./3.mp3" , duration : "3:35"},
    {id : 3 , name : "رویاهای نئونی - سایه الکتریکی" , cover : "./4.jpg" , src : "./4.mp3" , duration : "1:39"},
    {id : 2 , name : "زمزمه‌های باد - اورلیا نایت" , cover : "./5.png" , src : "./5.mp3" , duration : "2:34"},
    {id : 1 , name : "تعقیب غروب - خیال طلایی" , cover : "./6.jpg" , src : "./6.mp3" , duration : "1:30"},

]

 function showmusic () {
   
const musicscontainer = document.querySelector(".musics-container")

data.forEach(function(music){
  
    ////be ezaye harkodom az musicha insert anjam she
    
musicscontainer.insertAdjacentHTML("beforeend" , `
<article class="music-card">
<header>
  <img src="${music.cover}" alt="کاور موزیک">
  <div class="play-music">
    <button class="play-btn" data-src="${music.src}">
      <i class="fa-solid fa-play"></i>
    </button>
  </div>
</header>
<main>
  <p>${music.name}</p>
</main>
</article>`)

});
const durations = document.querySelector(".duration")
const playbtn = document.querySelectorAll(".play-btn")
const audios = document.querySelector("audio")
const forward = document.querySelector(".forward")
const favolumeup = document.querySelector(".volume-icon")
const playicon = document.querySelector(".play-icon")
const button = document.querySelector(".play-button")

const volumecard = document.querySelector(".volume-card")
const volume = document.querySelector(".volume")
//const playmusic = document.querySelector(".play-music")
const like = document.querySelector(".like")
//const header = document.querySelector("header")
//const img = document.querySelector("img")
const volumehandler = document.querySelector(".volume-handler")
const artist = document.querySelector(".artist")
//const timeleft = document.querySelector(".time-left")
//const processbar = document.querySelector(".process-bar")
const backforward = document.querySelector(".back-forward")
 const childvolume = volumehandler.firstElementChild;
let timerInterval = null

 function formatTime(seconds) {
    let min = Math.floor(seconds / 60);
    let sec = Math.floor(seconds % 60);
  
    // اگر تعداد ثانیه کمتر از 10 بود، یه صفر جلوش بذار
    if (sec < 10) {
      sec = "0" + sec;///az gbt beporsam yani chi in va format time (audio.)
    }
  
    return min + ":" + sec;
  }
  


  
  
playbtn.forEach(function(btn) {
    //console.log(btn);
    btn.addEventListener("click", function(event) {
       
        const src = event.target.dataset.src;
//console.log(src);
        audios.setAttribute("src", src);
       // musicname.innerHTML = 
       //console.log(audios);
       audios.play()
       //currentIndex = index;
        mainElem = btn.parentElement.parentElement.nextElementSibling;
       musicTitle = mainElem.querySelector("p").innerHTML;
       musicname.innerHTML = musicTitle;

       if (playicon.className.includes("fa-play")){
        playicon.classList.remove("fa-play")
        playicon.classList.add("fa-pause")
       }

       playbtn.forEach(function(btn){
             const playorpause = btn.querySelector("i")
                playorpause.classList.remove("fa-pause") ///reset mishe
                playorpause.classList.add("fa-play")
              
       })
       const playorpause = btn.querySelector("i")
       playorpause.classList.remove("fa-play") /// tozih az gbt
       playorpause.classList.add("fa-pause")


     
        // console.log(currentindex);
console.log(playorpause);




    });

    function startTimer () {
        timerInterval = setInterval(() => {
       
            if (!audios.paused) {
              timeleft.textContent = formatTime(audios.currentTime);
              durations.textContent = formatTime(audios.duration); ////to setinterval in avordam beporsam
            } else {
              clearInterval(timerInterval); // اگه موزیک pause شد، تایمر رو متوقف کن
            }
          }, 1000);  
    }

    audios.play();
    startTimer(); // اینجا مهمه // beporsam
    
  
});
button.addEventListener("click" , function(){
   
    if (playicon.className.includes("fa-play")){
        audios.play();
       
        playicon.classList.remove("fa-play")
        playicon.classList.add("fa-pause")
        //startTimer(); 
       } else {
        
        audios.pause();
       
        playicon.classList.remove("fa-pause")
        playicon.classList.add("fa-play")
        
       }
    const pauseicon = document.querySelector(".play-btn .fa-pause")
    console.log(pauseicon);
    if (pauseicon){
        pauseicon.classList.remove("fa-pause")
        pauseicon.classList.add("fa-play")
    }  
   /////faghat on btn ke in class o dre alan na hame btn ha va dakhelesh in class hast itemni kke in class ro dre 
///agar in data to dom bood oon vaght class o begire nabshe null , null falsy value hast pas if ejra nmishe

console.log(pauseicon);///null nemide 
})





//console.log(playicon);
function nextmusic () {
    //currentIndex = index; // حتماً اینو بزن!
     currentIndex++
     if (currentIndex > 5){
         currentIndex = 0
     }
    
     mainmusic = data[currentIndex]
     //currentIndex = index; 
     audios.setAttribute("src" , mainmusic.src) 
 
     artist.innerHTML = mainmusic.duration
 
    let save =  musicname.innerHTML = mainmusic.name;
 
     console.log(save);
                                   
     console.log(mainmusic);
     audios.play()                                                                              
     
     
 }
 forward.addEventListener("click" , nextmusic)

volumecard.addEventListener("click" , function(event){
    console.log(event.offsetX);///az same chap element ta raste 0 ta 100 mige koja click shode 
    
    audios.volume = event.offsetX / 100
    volume.style.width = `${event.offsetX}px` 
    })
    function mute () {

        if (favolumeup.className.includes("fa-volume-mute")){
            favolumeup.classList.remove("fa-volume-mute")
                favolumeup.classList.add("fa-volume-up")
                audios.volume = 1
                volume.style.width = `50px` 
        } else {
            favolumeup.classList.remove("fa-volume-up")
                favolumeup.classList.add("fa-volume-mute")
                audios.volume = 0
                volume.style.width = `0px` 
        }
           
                
            
         
        }
        function liking () {
       if (faheart.className.includes("fa-regular")){
        faheart.classList.remove("fa-regular")
        faheart.classList.add("fa-solid")
        faheart.style.color = "red"
       } else {
        faheart.classList.remove("fa-solid")
        faheart.classList.add("fa-regular")
        faheart.style.color = "currentcolor"
       }
          
            
        }
        childvolume.addEventListener("click" , mute)
        like.addEventListener("click" , liking)
        
        function  backmusic () {
            currentIndex--
            if (currentIndex < 0){
                currentIndex = 5
            }
            mainmusic = data[currentIndex]
            //currentIndex = index; 
            audios.setAttribute("src" , mainmusic.src) 
        
            artist.innerHTML = mainmusic.duration
        
           let save =  musicname.innerHTML = mainmusic.name;
        
            console.log(save);
                                          
            console.log(mainmusic);
            audios.play()    
        }
        
        backforward.addEventListener("click" , backmusic)
}

//console.log(playbtn);
/*

function formatTime(seconds) {
    const min = Math.floor(seconds / 60);
    const sec = Math.floor(seconds % 60);
    return `${min < 10 ? "0" + min : min}:${sec < 10 ? "0" + sec : sec}`;
  }
  
  // هر ثانیه مقدار currentTime می‌گیریم و داخل عنصر می‌ریزیم


musiccard.forEach(function(music) {
    //console.log(music);

   music.addEventListener("click", function() {
    musicname.innerHTML = main.firstElementChild.innerHTML
});
}); 

playbtn.forEach(function(btn , index) {
    
    console.log(btn);



    btn.addEventListener("click", function(event) {
       
        const src = event.target.dataset.src;
//console.log(src);
        audios.setAttribute("src", src);
       // musicname.innerHTML = 
       //console.log(audios);
      

       audios.play()
       currentIndex = index;
        mainElem = btn.parentElement.parentElement.nextElementSibling;
       musicTitle = mainElem.querySelector("p").innerHTML;
       musicname.innerHTML = musicTitle;
      

       if (playicon.className.includes("fa-play")){
        playicon.classList.remove("fa-play")
        playicon.classList.add("fa-pause")
       }

       playbtn.forEach(function(btn){
             const playorpause = btn.querySelector("i")
                playorpause.classList.remove("fa-pause")
                playorpause.classList.add("fa-play")
              
       })
       const playorpause = btn.querySelector("i")
       playorpause.classList.remove("fa-play")
       playorpause.classList.add("fa-pause")

    


       setInterval(() => {
        timeleft = audios.currentTime; // زمان فعلی بر حسب ثانیه
    timeleft.textContent = formatTime(timeleft);
     }, 1000);
   
        // console.log(currentindex);


    });

  
});







function nextmusic () {
   //currentIndex = index; // حتماً اینو بزن!
    currentIndex++
    if (currentIndex > 5){
        currentIndex = 0
    }
   
    mainmusic = data[currentIndex]
    //currentIndex = index; 
    audios.setAttribute("src" , mainmusic.src) 

    artist.innerHTML = mainmusic.duration

   let save =  musicname.innerHTML = mainmusic.name;

    console.log(save);
                                  
    console.log(mainmusic);
    audios.play()                                                                              
    
    
}




forward.addEventListener("click" , nextmusic)
button.addEventListener("click" , function(){
    if (playicon.className.includes("fa-play")){
        audios.play()
        playicon.classList.remove("fa-play")
        playicon.classList.add("fa-pause")
       } else {
        audios.pause()
        playicon.classList.remove("fa-pause")
        playicon.classList.add("fa-play")
        
       }
       
        pauseicon = document.querySelector(".play-btn .fa-pause")/////faghat on btn ke in class o dre alan na hame btn ha va dakhelesh in class hast itemni kke in class ro dre 


       pauseicon.classList.remove("fa-pause")
       pauseicon.classList.add("fa-play")
})


volumecard.addEventListener("click" , function(event){
console.log(event.offsetX);///az same chap element ta raste 0 ta 100 mige koja click shode 

audios.volume = event.offsetX / 100
volume.style.width = `${event.offsetX}px` 
})

/////volume hamishe beyn 0 ta 1 hast 
///defualt 1 hast yani balatarin

function mute () {

if (favolumeup.className.includes("fa-volume-mute")){
    favolumeup.classList.remove("fa-volume-mute")
        favolumeup.classList.add("fa-volume-up")
        audios.volume = 1
        volume.style.width = `50px` 
} else {
    favolumeup.classList.remove("fa-volume-up")
        favolumeup.classList.add("fa-volume-mute")
        audios.volume = 0
        volume.style.width = `0px` 
}
   
        
    
 
}
function liking () {
    
    const svg = like.firstElementChild
    console.log(svg);
    svg.setAttribute("fill" , "currentcolor")
}
childvolume.addEventListener("click" , mute)
like.addEventListener("click" , liking)

function  backmusic () {
    
    currentIndex--
    if (currentIndex < 0){
        currentIndex = 5
    }
    mainmusic = data[currentIndex]
    //currentIndex = index; 
    audios.setAttribute("src" , mainmusic.src) 

    artist.innerHTML = mainmusic.duration

   let save =  musicname.innerHTML = mainmusic.name;

    console.log(save);
                                  
    console.log(mainmusic);
    audios.play()    
}


//backforward.addEventListener("click" , backmusic)

///////////////rahe hal osooli ezaf kardan be dom 
//////data dar ghalebe araye va az tarugh insertadjacent
//////زchera function playbtn va baghie oomad to function show music
*/
///////////////////////soal error music stop mishe dge icon playbtn dorost nemishe